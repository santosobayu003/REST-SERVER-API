<?php
defined('BASEPATH') or exit('No direct script access allowed');

class C_perusahaan extends CI_Controller
{

    public function index()
    {
        $data = $this->M_tes->select('tb_perusahaan');
        var_dump($data);
        die;
    }

    public function select_by_id ()
    {
        $data = $this->M_tes->select_where('tb_perusahaan', 'id_perusahaan', '1');
        var_dump($data);
        die;
    }

    public function select_order ()
    {
        $data = $this->M_tes->select_order('tb_perusahaan', 'id_perusahaan', 'DESC');
        var_dump($data);
        die;
    }

    function insert_data ()
    	{
    		$field = array (
    						'perusahaan_name' => $this->input->post ('perusahaan_name') ,
    						'perusahaan_address' => $this->input->post ('perusahaan_address') ,
    						'requirement' =>  $this->input->post ('requirement'),
    					  );

                          var_dump($data);
                          die;
    	}
}
