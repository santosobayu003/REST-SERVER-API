<?php

class M_tes extends  CI_Model
{

    public function select($table)
    {
        return  $this->db->get($table)->result_array();
    }

    public function select_order ($table, $orderBy, $short)
    {
        $this->db->order_by($orderBy, $short);
        return  $this->db->get($table)->result_array();
    }

    public function select_where ($table, $where, $id)
    {
        return  $this->db->get_where($table, [$where => $id])->result_array();
    }

    function insert($table, $field)
    {
        $this->db->insert($table, $field);
        return $this->db->affected_rows();
    }
}
